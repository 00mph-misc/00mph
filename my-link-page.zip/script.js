// Small interaction: clicking a link gives subtle feedback.
document.querySelectorAll(".link-card").forEach((link) => {
  link.addEventListener("click", () => {
    link.style.transform = "scale(.98)";
    setTimeout(() => {
      link.style.transform = "";
    }, 120);
  });
});
